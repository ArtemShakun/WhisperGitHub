const flatArray = arr =>
    arr.flat();