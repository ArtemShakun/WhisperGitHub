const getSpecialNumbers = arr => arr.filter(num => num % 3 === 0);
